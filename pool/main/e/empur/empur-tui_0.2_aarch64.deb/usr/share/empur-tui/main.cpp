#include <curses.h>
#include <curl/curl.h>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <locale.h>
#include <sys/stat.h>

// ─── 配置结构 ───
struct Config {
    std::string city = "Macau";
    std::string news_rss = "https://news.yahoo.com/rss";
    int refresh_min = 15;
    bool push_on_start = true;
    std::string weather_unit = "C";
    std::string push_mode = "notification";   // "notification" 或 "autostart"
    std::string autostart_path = "";          // 空=自动检测
};

static Config g_cfg;

static std::string config_path() {
    const char* h = getenv("HOME");
    return std::string(h ? h : ".") + "/.empur.toml";
}

// ─── save_config ───
static void save_config() {
    std::ofstream f(config_path());
    f << "# empur-tui config\n";
    f << "city = \"" << g_cfg.city << "\"\n";
    f << "news_rss = \"" << g_cfg.news_rss << "\"\n";
    f << "refresh_min = " << g_cfg.refresh_min << "\n";
    f << "push_on_start = " << (g_cfg.push_on_start ? "true" : "false") << "\n";
    f << "weather_unit = \"" << g_cfg.weather_unit << "\"\n";
    f << "push_mode = \"" << g_cfg.push_mode << "\"\n";
    f << "autostart_path = \"" << g_cfg.autostart_path << "\"\n";
    f.close();
}

// ─── load_config ───
static void load_config() {
    std::ifstream f(config_path());
    if (!f.good()) { save_config(); return; }
    std::string line;
    while (std::getline(f, line)) {
        line.erase(0, line.find_first_not_of(" \t"));
        if (line.empty() || line[0] == '#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = line.substr(0, eq);
        std::string val = line.substr(eq + 1);
        key.erase(0, key.find_first_not_of(" \t"));
        key.erase(key.find_last_not_of(" \t") + 1);
        val.erase(0, val.find_first_not_of(" \t\""));
        val.erase(val.find_last_not_of(" \t\"") + 1);
        if (key == "city") g_cfg.city = val;
        else if (key == "news_rss") g_cfg.news_rss = val;
        else if (key == "refresh_min") g_cfg.refresh_min = atoi(val.c_str());
        else if (key == "push_on_start") g_cfg.push_on_start = (val == "true");
        else if (key == "weather_unit") g_cfg.weather_unit = val;
        else if (key == "push_mode") g_cfg.push_mode = val;
        else if (key == "autostart_path") g_cfg.autostart_path = val;
    }
    f.close();
}

// ─── 极简 JSON ───
static std::string json_get(const std::string& raw, const std::string& key) {
    std::string qkey = "\"" + key + "\":";
    size_t pos = raw.find(qkey);
    if (pos == std::string::npos) return "";
    pos += qkey.size();
    while (pos < raw.size() && (raw[pos] == ' ' || raw[pos] == '\t')) pos++;
    if (pos >= raw.size()) return "";
    if (raw[pos] == '"') {
        pos++;
        size_t end = raw.find('"', pos);
        if (end == std::string::npos) return "";
        return raw.substr(pos, end - pos);
    } else {
        size_t end = pos;
        while (end < raw.size() && raw[end] != ',' && raw[end] != '}' && raw[end] != ' ' && raw[end] != '\n') end++;
        return raw.substr(pos, end - pos);
    }
}

// ─── curl ───
static size_t write_cb(void* data, size_t size, size_t nmemb, std::string* buf) {
    buf->append((char*)data, size * nmemb);
    return size * nmemb;
}

static std::string fetch(const std::string& url) {
    std::string buf;
    CURL* c = curl_easy_init();
    if (!c) return "";
    struct curl_slist* h = NULL;
    h = curl_slist_append(h, "User-Agent: empur-tui/0.1");
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &buf);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(c, CURLOPT_HTTPHEADER, h);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_perform(c);
    curl_slist_free_all(h);
    curl_easy_cleanup(c);
    return buf;
}

// ─── 天气 ───
static std::string get_weather() {
    std::string fmt = (g_cfg.weather_unit == "F") ? "4" : "3";
    std::string url = "https://wttr.in/" + g_cfg.city + "?format=" + fmt;
    std::string r = fetch(url);
    while (!r.empty() && (r.back() == '\n' || r.back() == '\r')) r.pop_back();
    return r.empty() ? "获取失败" : r;
}

// ─── 一言 ───
static std::string get_quote() {
    std::string r = fetch("https://v1.hitokoto.cn/");
    if (r.empty()) return "获取失败";
    std::string text = json_get(r, "hitokoto");
    std::string from = json_get(r, "from");
    std::string who = json_get(r, "from_who");
    if (text.empty()) return "解析失败";
    std::string out = text;
    if (!who.empty()) out += " —— " + who;
    else if (!from.empty()) out += " —— " + from;
    return out;
}

// ─── 新闻 ───
static std::vector<std::string> get_news() {
    std::vector<std::string> out;
    std::string url = "https://api.rss2json.com/v1/api.json?rss_url=" + g_cfg.news_rss;
    std::string r = fetch(url);
    if (r.empty()) { out.push_back("获取失败"); return out; }
    size_t pos = 0, count = 0;
    while (count < 5) {
        size_t tpos = r.find("\"title\":", pos);
        if (tpos == std::string::npos) break;
        tpos += 8;
        while (tpos < r.size() && (r[tpos] == ' ' || r[tpos] == '\t')) tpos++;
        if (tpos >= r.size() || r[tpos] != '"') { pos = tpos; continue; }
        tpos++;
        size_t end = r.find('"', tpos);
        if (end == std::string::npos) break;
        std::string title = r.substr(tpos, end - tpos);
        if (count > 0 || title.find("rss") == std::string::npos) {
            if (!title.empty()) { out.push_back(title); count++; }
        }
        pos = end + 1;
        if (count >= 5) break;
    }
    if (out.empty()) out.push_back("暂无新闻");
    return out;
}

// ─── 推送（通知栏模式） ───
static void push_notification() {
    std::string w = get_weather();
    std::string q = get_quote();
    auto news = get_news();

    std::string content = w + "\n\n「" + q + "」\n\n";
    for (size_t i = 0; i < news.size() && i < 3; i++)
        content += std::to_string(i + 1) + ". " + news[i] + "\n";

    std::string safe = content;
    for (size_t i = 0; i < safe.size(); i++) {
        if (safe[i] == '\'') { safe.insert(i, "'"); i++; }
    }

    std::string cmd = "termux-notification --title 'empur-tui' --content '" + safe + "' 2>/dev/null";
    int ret = system(cmd.c_str());
    if (ret != 0) {
        std::ofstream log(std::string(getenv("HOME")) + "/empur-last.txt");
        log << content;
        log.close();
    }
}

// ─── 自动启动管理 ───
static std::string detect_autostart_path() {
    if (!g_cfg.autostart_path.empty()) return g_cfg.autostart_path;

    // 自动检测：优先 ~/.bashrc，不存在则用 ~/.profile
    const char* h = getenv("HOME");
    std::string bashrc = std::string(h ? h : "") + "/.bashrc";
    std::string profile = std::string(h ? h : "") + "/.profile";

    struct stat st;
    if (stat(bashrc.c_str(), &st) == 0) return bashrc;
    return profile;
}

static std::string autostart_line() {
    const char* h = getenv("HOME");
    return std::string("~/empur-tui/empur push &  # empur-tui autostart");
}

static void install_autostart() {
    std::string path = detect_autostart_path();
    std::string line = autostart_line();

    // 检查是否已存在
    std::ifstream fin(path);
    std::string content, fileline;
    bool found = false;
    while (std::getline(fin, fileline)) {
        if (fileline.find("empur-tui autostart") != std::string::npos) {
            found = true;
            break;
        }
    }
    fin.close();

    if (!found) {
        std::ofstream fout(path, std::ios::app);
        fout << "\n" << line << "\n";
        fout.close();
    }
}

static void remove_autostart() {
    std::string path = detect_autostart_path();
    std::ifstream fin(path);
    if (!fin.good()) return;

    std::string new_content;
    std::string fileline;
    while (std::getline(fin, fileline)) {
        if (fileline.find("empur-tui autostart") == std::string::npos) {
            new_content += fileline + "\n";
        }
    }
    fin.close();

    std::ofstream fout(path);
    fout << new_content;
    fout.close();
}

// ─── TUI 设置界面 ───
static void settings_ui() {
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    timeout(100);

    int sel = 0;
    const char* items[] = {
        "城市",
        "新闻 RSS 源",
        "刷新间隔(分钟)",
        "启动时推送",
        "温度单位(C/F)",
        "推送方式 (通知栏/开机自启)",
        "开机启动配置路径",
        "── 保存并退出 ──",
        "── 退出不保存 ──",
    };
    const int N = sizeof(items) / sizeof(items[0]);

    bool dirty = false;
    bool done = false;
    while (!done) {
        werase(stdscr);
        int h, w;
        getmaxyx(stdscr, h, w);

        attron(A_REVERSE | A_BOLD);
        mvhline(0, 0, ' ', w);
        mvprintw(0, 2, " empur-tui v0.2 ");
        attroff(A_REVERSE | A_BOLD);

        for (int i = 0; i < N; i++) {
            int y = 2 + i;
            if (i == sel) attron(A_REVERSE);
            mvprintw(y, 2, " %s", items[i]);

            if (i == 0) mvprintw(y, 28, "[%s]", g_cfg.city.c_str());
            else if (i == 1) mvprintw(y, 28, "[%s]", g_cfg.news_rss.c_str());
            else if (i == 2) mvprintw(y, 28, "[%d]", g_cfg.refresh_min);
            else if (i == 3) mvprintw(y, 28, "[%s]", g_cfg.push_on_start ? "是" : "否");
            else if (i == 4) mvprintw(y, 28, "[%s]", g_cfg.weather_unit.c_str());
            else if (i == 5) mvprintw(y, 28, "[%s]", g_cfg.push_mode == "notification" ? "通知栏" : "开机自启");
            else if (i == 6) {
                std::string disp = g_cfg.autostart_path.empty() ? "(自动检测)" : g_cfg.autostart_path;
                mvprintw(y, 28, "[%s]", disp.c_str());
            }

            if (i == sel) attroff(A_REVERSE);
        }

        mvprintw(h - 1, 2, " j/k或↑↓选择  Enter编辑  空格切换  s保存启动配置  q退出 ");
        refresh();

        int ch = getch();
        switch (ch) {
            case KEY_UP:
            case 'k': sel = (sel - 1 + N) % N; break;
            case KEY_DOWN:
            case 'j': sel = (sel + 1) % N; break;
            case ' ':
                if (sel == 3) g_cfg.push_on_start = !g_cfg.push_on_start;
                else if (sel == 4) g_cfg.weather_unit = (g_cfg.weather_unit == "C") ? "F" : "C";
                else if (sel == 5) {
                    g_cfg.push_mode = (g_cfg.push_mode == "notification") ? "autostart" : "notification";
                    dirty = true;
                }
                break;
            case '\n':
            case KEY_ENTER: {
                char buf[512] = {0};
                timeout(-1);
                curs_set(1);

                if (sel == 0) {
                    echo();
                    mvprintw(h - 2, 2, "城市名: ");
                    clrtoeol();
                    refresh();
                    wgetnstr(stdscr, buf, sizeof(buf) - 1);
                    noecho();
                    if (buf[0]) { g_cfg.city = buf; dirty = true; }
                } else if (sel == 1) {
                    echo();
                    mvprintw(h - 2, 2, "RSS URL: ");
                    clrtoeol();
                    refresh();
                    wgetnstr(stdscr, buf, sizeof(buf) - 1);
                    noecho();
                    if (buf[0]) { g_cfg.news_rss = buf; dirty = true; }
                } else if (sel == 2) {
                    echo();
                    mvprintw(h - 2, 2, "分钟数: ");
                    clrtoeol();
                    refresh();
                    wgetnstr(stdscr, buf, sizeof(buf) - 1);
                    noecho();
                    int v = atoi(buf);
                    if (v > 0) { g_cfg.refresh_min = v; dirty = true; }
                } else if (sel == 5) {
                    // 推送方式：Enter 也切换
                    g_cfg.push_mode = (g_cfg.push_mode == "notification") ? "autostart" : "notification";
                    dirty = true;
                } else if (sel == 6) {
                    // 自定义开机启动路径
                    echo();
                    mvprintw(h - 2, 2, "启动配置路径 (空=自动): ");
                    clrtoeol();
                    refresh();
                    wgetnstr(stdscr, buf, sizeof(buf) - 1);
                    noecho();
                    g_cfg.autostart_path = buf;
                    dirty = true;
                } else if (sel == 7) {
                    // 保存并退出
                    save_config();
                    if (g_cfg.push_mode == "autostart") {
                        install_autostart();
                        mvprintw(h - 2, 2, " 已写入开机启动配置 ");
                    } else {
                        remove_autostart();
                    }
                    clrtoeol();
                    refresh();
                    usleep(800000);
                    done = true;
                } else if (sel == 8) {
                    done = true;
                }

                timeout(100);
                curs_set(0);
                mvprintw(h - 2, 0, "");
                clrtoeol();
                break;
            }
            case 's':
            case 'S': {
                // 快捷键 s：立即应用启动配置
                save_config();
                if (g_cfg.push_mode == "autostart") {
                    install_autostart();
                    mvprintw(h - 2, 2, " 已写入开机启动: %s ", detect_autostart_path().c_str());
                } else {
                    remove_autostart();
                    mvprintw(h - 2, 2, " 已移除开机启动 ");
                }
                clrtoeol();
                refresh();
                usleep(1000000);
                mvprintw(h - 2, 0, "");
                clrtoeol();
                break;
            }
            case 'q':
            case 'Q':
                done = true;
                break;
        }
    }
    endwin();
}

// ─── main ───
int main(int argc, char** argv) {
    curl_global_init(CURL_GLOBAL_ALL);
    setlocale(LC_ALL, "");
    load_config();

    if (argc > 1 && std::string(argv[1]) == "push") {
        push_notification();
        curl_global_cleanup();
        return 0;
    }

    settings_ui();
    curl_global_cleanup();
    return 0;
}
